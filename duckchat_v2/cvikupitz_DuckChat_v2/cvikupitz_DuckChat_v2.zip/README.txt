Name: Cole Vikupitz
DuckID: 951374618
CIS 432/532
Programming Assignment 2
DuckChat v2